﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polymorphism
{
    class polymorphism
    {
        public void disp(int a, int b)
        {
            int c = a + b;
            Console.WriteLine("addition is " + c);
        }
        public void disp(float p, float q)
        {
            float r = p + q;
            Console.WriteLine("addition is " + r);
        }
        public void disp(double s, double t)
        {
            double z = s + t;
            Console.WriteLine("addition of double is " + z);
        }

    }
    class mIN
    {
        public static void Main(String[] args)
        {

            polymorphism pp = new polymorphism();

            pp.disp(10, 10);
            pp.disp(1.5, 10.5);
            pp.disp(11.25f, 20.25f);
            Console.ReadLine();     
        }
    }

}