﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstract_class
{

    abstract class human
    {
        public abstract void gender();
    }

    class Man : human
    {
        public override void gender()
        {
            Console.WriteLine("male");

        }
    }
    class WOMan : human
    {
        public override void gender()
        {
            Console.WriteLine("female");
        }
    }
    class program
    {
        static void Main(String[] args)
        {
            Man mm =new Man();
     
           WOMan ww=new WOMan();
        mm.gender();
            ww.gender();
            //ww.GetHashCode();
            Console.ReadLine();
        }
    }
}