﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;


//stack=last in first out 
//queue=First in first out



namespace Runime_polymorphism
{
    class parent
    {
        public virtual void disp()
        {
            Stack ss = new Stack();
            ss.Push("java");
            ss.Push("dotnet");
            ss.Push("php");
            ss.Push("pearl");
            ss.Push("ruby");
            foreach (string str in ss)
            {
                Console.WriteLine("the elements in the stack are :" + str);
            }
           
                Console.WriteLine("after popping the element is" + ss.Pop());
         
                foreach(string PP in ss)
            {
                
                Console.WriteLine("the elements in the stack(popping) are :" + PP);
            }
        }
    }
    class child : parent
    {
        public override void disp()
        {
            Queue qq = new Queue();
            qq.Enqueue("bangalore");
            qq.Enqueue("mysore");
            qq.Enqueue("ooty");
            qq.Enqueue("coimbatore");
            foreach (string hh in qq)
            {
                Console.WriteLine("the elements present in the queue are :" + hh);
            }
                Console.WriteLine("the elemnts present in dequeing are:" + qq.Dequeue());
            foreach (string rr in qq)
            {
                Console.WriteLine("the elements present after the queue(dequeuing) are :" + rr);
            }
        }
    }
    class main
    {
        public static void Main(String[] args)
        {
            parent pp = new parent();
            child cc = new child();
            pp.disp();
            cc.disp();
            Console.ReadLine();
        }
    }
}
