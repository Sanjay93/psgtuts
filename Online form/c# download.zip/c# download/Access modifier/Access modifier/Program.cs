﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Access_modifier
{
   class Parent
   {
       private string name;
       protected string  address;
       protected internal string city;
       internal int age;
       public  virtual void display()
       {
           address="papanaicken palayam";
           name="sanjay"; 
           Console.WriteLine("the name of student is :"+ name);
           Console.WriteLine("the address of the student is :"+ address);
       }
   }
   class child : Parent
   {
       public override void display()
       {
           

           for (int i = 0; i < 5; i++)
           {
               if (i == 3)
               {
                   continue;
               }
               else
               {
                   Console.WriteLine(i);
               }

           }
       }
   }
        class main
        {
            public static void Main(String[] args)
            {
                
                Parent pp=new Parent();
                child cc=new child();
                pp.age=20;
                pp.city="coimbatore";
                cc.display();
                pp.display();
                Console.ReadLine();
            }
        }

}
