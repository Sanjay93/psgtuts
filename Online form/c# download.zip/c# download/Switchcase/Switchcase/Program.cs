﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Switchcase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("BANGALORE");
            Console.WriteLine("mumbai");
            Console.WriteLine("chennai");
            Console.WriteLine("enter the choice");
            string str = Console.ReadLine();
            switch (str)
            {
                case "BANGALORE":
                    Console.WriteLine("karnataka");
                    break;
                case "chennai":
                    Console.WriteLine("tamilnadu");
                    break;
                case "mumbai":
                    Console.WriteLine("MAHARASTRA");
                    break;

            }
            Console.ReadLine();
        }
    }
}
