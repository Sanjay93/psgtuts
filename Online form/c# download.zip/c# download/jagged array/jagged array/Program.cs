﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace jagged_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] jag = new int[4][];
            jag[0] = new int[2] { 5, 9 };
            jag[1] = new int[3] { 5, 4, 66 };
            jag[2] = new int[6] { 1, 2, 4, 5, 7, 9 };
            jag[3] = new int[2] { 9, 6 };
        for(int i=0;i<jag.Length;i++)
        {
            Console.WriteLine("Element({0}):" , i+1);
            for(int j=0;j<jag[i].Length;j++)
            {
                Console.WriteLine(jag[i][j] + "\t");
            }
            Console.WriteLine();
        }
    Console.ReadLine();
        }
    }
}