﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            int [] a={1,55,60,7,11,23};
            foreach(int ii in a)
            {
                Console.WriteLine("the elements are present in" +ii);
            }
            Array.Sort(a);
            Array.Reverse(a);
            foreach(int pp in a)
            {
                Console.WriteLine("the elements present in the array" +pp);
        }
    Console.ReadLine();
        }
    }
}