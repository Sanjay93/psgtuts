﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encapsualtion
{

    class encaps
    {
        private string password;
        public void  setpassword(string npassword)
        {
            password=npassword;
        
        }
        public string  getpassword()
        {            return password;
        }
    }
    class main
    {
        static void Main(String[] args)
        {
            Console.WriteLine("enter the password");
            string npassword=Console.ReadLine();
            encaps e=new encaps();
            e.setpassword(npassword);
            string pass=e.getpassword();
            Console.WriteLine("the password is "+ pass);
            Console.ReadLine(); 
        }
    }
}







