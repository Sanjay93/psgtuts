﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @interface
{
    interface sanjay
    {
        void insert();
        
    }
    class parent : sanjay
    {
        public void insert()
        {
            Console.WriteLine("insert in login table");
        }
        public void update()
        {
            Console.WriteLine("update in login table");
        }
    }
    class child : sanjay
    {
        public void insert()
        {
            Console.WriteLine("insert in register table");
        }
        public void update()
        {
            Console.WriteLine("update in registee table");
        }
       

    }
    class main
    {
        public static void Main(String[] args)
        {
        parent pp=new parent();
        child cc=new child();
        pp.insert();
        cc.insert();
        Console.ReadLine();
        }
    }
}
