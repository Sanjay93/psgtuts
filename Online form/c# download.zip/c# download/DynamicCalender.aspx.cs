﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

public partial class DynamicCalender : System.Web.UI.Page
{
    OleDbConnection con = new OleDbConnection("Provider=SQLOLEDB;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=CHENNAI;Data Source=MAZENET-PC");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        
        string hh = "insert into stamp values('" + TextBox1.Text + "','" + TextBox2.Text + "')";
        OleDbCommand cmd = new OleDbCommand(hh, con);
        cmd.ExecuteNonQuery();
        con.Close();

    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToString("dd/MM/yyyy");
    }
}