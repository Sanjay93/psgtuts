﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace inheritance
{
   class Parent
   {
       public string name;
       public string address;
       public string city;
       public void display()
       { 
           Console.WriteLine("\nthe name of the student is" + name);
           Console.WriteLine("\nthe address of the student is" + address);
           Console.WriteLine("\nthe city of the student is" + city);
       }
   }
       class child:Parent
       {
           public int age;
           public string state;
           public void Disp()
           {
           Console.WriteLine("the age of the student is"+ age);
           Console.WriteLine("the state of the student is"+ state);
           }
       }

        class main
        {
           static void Main(String[] args)
            {
                child cc=new child();
                cc.name="Sanjay";
                cc.state="TamilNadu";
                cc.city="Coimbatore";
                cc.age=20;
                cc.address="Pappanaicken palayam";
                cc.Disp();
                cc.display();
                Console.ReadLine();
            }
        }
}
