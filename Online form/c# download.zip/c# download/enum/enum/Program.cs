﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @structure
{
    /*struct student
    {
        public int id;
        public string name;
        public double coursefee;
        public string couresename;
    }*/

    struct Rectange
    {
        public int width ;
        public int length;
        public int res;
        
     
       
        public int calc(int w,int l)
        {
             width=w ;
             length=l ;
        res= width* length;
        return res;
        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            Rectange rr = new Rectange();
            rr.calc(100,200);
            Console.WriteLine("the rectangle is :" + rr.res);
            Console.ReadLine();
        }
    }
}
