﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constructor
{
    class Rectangle
    {
        public int width, length;
        public Rectangle(int w, int l)
        {
            width = w;
            length = l;
        }
        public int getData()
        {
            return width * length;
        }
    }
    class main
    {

        public static void Main(String[] args)
        {
       
        int a,b;
      
        Console.WriteLine("enter the numbers:");
        a=Convert.ToInt32(Console.ReadLine());
        b=Convert.ToInt32(Console.ReadLine());
        Rectangle rr = new Rectangle(a, b);
            int res=rr.getData();
            Console.WriteLine("the result is" +res);
            Console.ReadLine();
        }
    }
}
         




