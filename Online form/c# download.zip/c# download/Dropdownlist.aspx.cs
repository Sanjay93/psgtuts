﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dropdownlist : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void drp1_SelectedIndexChanged(object sender, EventArgs e)
    {
        double firstno = Convert.ToDouble(txt1.Text);
        double secondno = Convert.ToDouble(txt2.Text);
        if(drp1.SelectedIndex == 1)
        {
            double add = firstno + secondno;
            label1.Text = "Addition is :" + add;
        }
        if (drp1.SelectedIndex == 2)
        {
            double sub = firstno - secondno;
            label1.Text = "Subtraction is :" + sub;
        }
        if (drp1.SelectedIndex == 3)
        {
            double mul = firstno * secondno;
            label1.Text = "Multiplication is :" + mul;
        }
        if (drp1.SelectedIndex == 4)
        {
            double div = firstno / secondno;
            label1.Text = "Division is :" + div;
        }
    }
    protected void txt1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txt2_TextChanged(object sender, EventArgs e)
    {

    }
}
